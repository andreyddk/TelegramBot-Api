#include "api/telegram.hpp"

#define CHAT_ID "220868168"

int main()
{
	telegram tb;
	message msg;
	//msg.sendMessage(CHAT_ID, "Example Message");
	//tb.getMe();
	//tb.getUpdates();
	
	cout << endl;
	
	return 0;
}